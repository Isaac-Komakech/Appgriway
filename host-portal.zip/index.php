<!DOCType html>
<html>
<head>
	<title>e-farmer</title>
	<link rel="stylesheet" href="style.css">
</head>
<body>
<div style="background-color: #AA0000; padding: 25px; margin-left: -10px; margin-top: -10px; float: left; //padding-bottom: 100px; //width: auto; height: 100%;">
	<br />
	<img src="icon.png">
	<br />
	<div class="login">
		<p><h1>e-farmer Portal</h1></p>
		<form action="home.html" method="post">
			<input type="text" name="name" placeholder="username e.g eamon"><br />
			<input type="password" name="pass" placeholder="password"><br />
			<input type="submit" value="Log in">
		</form>
	</div>
</div>  

<div style="background-image: url(image1.jpeg); background-repeat: no-repeat; background-size: cover; padding: 20px; margin: -10px; //padding-bottom: 170px; //margin-right: -15px; //margin-top: -200px; //width: auto; min-height: 100%; height: auto; right: 0px;">
	<div style="text-align: right; margin-top: 20px;">

		<p>
		<select style="background-color: #EEEEEE;" id="langselector" onchange="loadlang()">
		  <option value="en">English</option>
		  <option value="cw">Chichewa</option>
		  <option value="ch">Chinese (Simplified)</option>
		  <option value="cs">Corsican</option>
		  <option value="cr">Croatian</option>
		  <option value="da">Danish</option>
		  <option value="du">Dutch</option>
		  <option value="es">Esperanto</option>
		  <option value="et">Estonian</option>
		  <option value="fp">Filipino</option>
		  <option value="fn">Finnish</option>
		  <option value="fr">French</option>
		  <option value="fs">Frisian</option>
		  <option value="gl">Galician</option>
		  <option value="gg">Georgian</option>
		  <option value="ge">German</option>
		  <option value="gr">Greek </option>
		  <option value="gj">Gujarati</option>
		  <option value="ha">Haitian Creole</option>
		  <option value="hu">Hausa</option>
		  <option value="hw">Hawaiian</option>
		  <option value="hb">Hebrew</option>
		  <option value="hn">Hindi</option>
		  <option value="hr">Hungarian</option>
		  <option value="ic">Icelandic</option>
		  <option value="ig">Igbo</option>
		  <option value="in">Indonesian</option>
		  <option value="ir">Irish Gaelic</option>
		  <option value="it">Italian</option>
		  <option value="jp">Japanese</option>
		  <option value="ja">Javanese</option>
		  <option value="ka">Kannada</option>
		  <option value="kz">Kazakh</option>
		  <option value="km">Khmer</option>
		  <option value="kw">Kinyarwanda</option>
		  <option value="kr">Korean</option>
		  <option value="kd">Kurdish</option>
		  <option value="lv">Latvian</option>
		  <option value="lt">Lithuanian</option>
		  <option value="lm">Luxembourgish</option>
		  <option value="mc">Macedonian</option>
		  <option value="mg">Malagasy</option>
		  <option value="ml">Malay</option>
		  <option value="mm">Malayalam</option>
		  <option value="ma">Maori</option>
		  <option value="mr">Marathi</option>
		  <option value="mo">Mongolian</option>
		  <option value="ne">Nepali</option>
		  <option value="pe">Persian</option>
		  <option value="pu">Punjabi</option>
		  <option value="ro">Romanian</option>
		  <option value="ru">Russian</option>
		  <option value="se">Serbian</option>
		  <option value="ss">Sesotho</option>
		  <option value="sh">Shona</option>
		  <option value="si">Sindhi</option>
		  <option value="sl">Sinhala</option>
		  <option value="sk">Slovak</option>
		  <option value="sn">Slovenian</option>
		  <option value="sm">Somali</option>
		  <option value="sd">Sundanese</option>
		  <option value="sw">Swahili</option>
		  <option value="ta">Tajik</option>
		  <option value="tm">Tamil</option>
		  <option value="tl">Telugu</option>
		  <option value="th">Thai</option>
		  <option value="tk">Turkish</option>
		  <option value="ur">Urkrainian</option>
		  <option value="ug">Uyghur</option>
		  <option value="vt">Vietnamese</option>
		  <option value="xh">Xhosa</option>
		  <option value="yo">Yoruba</option>
		  <option value="zu">Zulu</option>
		  
		</select>

		<div id="google_translate_element"></div>

		<script type="text/javascript">
		function googleTranslateElementInit() {
		  new google.translate.TranslateElement({pageLanguage: 'en'}, 'google_translate_element');
		}
		</script>

		<!--
		<script type="text/javascript" src="http://translate.google.com/translate_a/element.js?cb=googleTranslateElementInit"></script>
		-->		

	<a href="signup.html">Sign Up</a> | <a href="#">Blog</a> </p>
	</div>
	<p style="margin: 200px;">
		<center>
			<h1 style="font-family: Comic sans ms;">Beyond Pandemics, Beyond Borders</h1> <br />
		</center>
	</p>

	<p>
	Appgriway is a virtual collaborative app that aims to connect different general publics, 
	local agricultural communities, refugees, neighborhoods, households and different ethnic groups to share experiences, information,
	knowledge, best practices and lessons learnt on farming, agri-business among other livelihood issues pertinent to 
	the agriculture industry.
	</p>
	<br />
	<br />
	<br />
	<br />
	<footer>
		&copy 2021 &nbsp;<a href=""https://idauganda.wordpress.com">Intercultural Development Agency</a>&nbsp;&nbsp;<span style="color: #000;">|</span>&nbsp;&nbsp;By <a id="author" href="http://www.github.com/isaac-komakech">
		Komakech Isaac</a>&nbsp;&nbsp;<a id="author" href="https://maytech0.000webhostapp.com/">Maytech Inc.</a>
	</footer>
</div> 
</body>
</html>