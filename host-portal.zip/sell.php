<!DOCType html>
<html>
<head>
	<title>Appgriway | Sell </title>
	<link rel="stylesheet" href="style.css">
	<link rel="stylesheet" href="bootstrap.min.css">
</head>
<body>

<div style="background-color: #AA0000; padding: 25px; width: auto; margin: -10px; //margin-left: -10px; //margin-top: -10px; //padding-bottom: 100px;">

<div style="float: left; padding: 8px;"><img src="icon.png">&nbsp;&nbsp;&nbsp;<font color="red" size="5px"><b>e-farmer Portal</b></font></div>

<ul class="nav justify-content-end">
  <li class="nav-item">
    <a class="nav-link" href="feed.html">Feed</a>
  </li>
  <li class="nav-item">
    <a class="nav-link" href="market.php">Markets</a>
  </li>
  <li class="nav-item">
    <a class="nav-link disabled" href="#">Sell</a>
  </li>
  <li class="nav-item">
    <a class="nav-link" href="blog.html">Blog</a>
  </li>
  <li class="nav-item dropdown">
        <a class="nav-link dropdown-toggle" href="downloads.html" id="navbarDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
          Downloads
        </a>
        <div class="dropdown-menu" aria-labelledby="navbarDropdown">
          <a class="dropdown-item" href="#">Policies</a>
          <a class="dropdown-item" href="#">Support Programs</a>
          <div class="dropdown-divider">|</div>
		  <a class="dropdown-item" href="#">Policies</a>
        </div>
   </li>
  <li class="nav-item">
    <a class="nav-link" href="index.html">Log Out</a>
  </li>
</ul>

</div>
<div style="background-color: #3ddc84; color: #000000; padding: 20px; width: auto; margin: -10px; min-height: 100%; //background-color: #3ddcea;">

<div style="color: #000000 ! important; padding: 20px; padding-right: 60px; margin-right: 140px; min-height: 100%; width: auto;">

<p>
<h2>What're you selling?</h2>
<b>Share: </b>
<br />
<table border="0px" style="color: #000000;">
	<form action="#" method="post">
		<tr><td>Business Name:</td>
			<td><input type="text" name="bname" placeholder="(optional)" /></td>
		</tr>
		<tr><td>Contact:</td>
			<td><input type="text" name="contact" placeholder="(Phone/Email)" /></td>
		</tr>
		<tr><td>Add Photo:</td>
			<td><input type="submit" value="Attach"/></td>
		</tr>
		<tr>
			<td>Description:</td>
			<td><textarea name="description" rows="14" cols="25" placeholder="brief"></textarea></td></tr>
		<tr><td></td><td><input type="submit" value="Post"></td></tr>
	</form>
	<tr>
		<td></td>
		<td></td>
	</tr>
	<tr>
		<td></td>
		<td>
		<?php
			echo htmlspecialchars($_POST["bname"]). "&nbsp;&nbsp;&nbsp;" . "<b>is selling</b>" . "<br />" . "<br />";
			echo htmlspecialchars($_POST["description"]);
			echo htmlspecialchars($_POST["photo"] . "<br />" . "<br />"); 
			echo htmlspecialchars($_POST["contact"]);
		?>
		</td>
	</tr>
</table>
</p>

<br /><br />
</div>
<div style="padding: 20px; width: auto; min-height: 100%; height: auto;">

</div>
<footer>
	&copy 2021 &nbsp;<a href=""https://idauganda.wordpress.com">Intercultural Development Agency</a>&nbsp;&nbsp;<span style="color: #000;">|</span>&nbsp;&nbsp;By <a id="author" href="http://www.github.com/isaac-komakech">
	Komakech Isaac</a>&nbsp;&nbsp;<a id="author" href="https://maytech0.000webhostapp.com/">Maytech Inc.</a>
</footer>

</div>
</body>
</html>